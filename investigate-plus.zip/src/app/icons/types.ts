export type IconProps = {
  size?: number;
  color?: string;
};
