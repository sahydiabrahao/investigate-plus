export type FileLinkData = {
  casePath: string;
  relativePath: string;
  displayName?: string;
};
